<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="http://localhost/evaluations_wf3/3_Evaluation_alexis_simoes/asset/css/style.css">
    <title>Document</title>
</head>
<body>
    <nav>
        <div>
            <a href="http://localhost/evaluations_wf3/3_Evaluation_alexis_simoes/accueil.php"><h1>Le Bon Appart</h1></a>
        </div>
        <ul>
            <li><a href="http://localhost/evaluations_wf3/3_Evaluation_alexis_simoes/add_annonce.php">Ajouter une annonce</a></li>
            <li><a href="http://localhost/evaluations_wf3/3_Evaluation_alexis_simoes/all_annonces.php">Consulter toutes les annonce</a></li>
        </ul>
    </nav>